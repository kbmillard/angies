# Angie's KC — Typography & Motion Handoff

Drop-in companion to `production-visual-spec.txt`. Stack target:

- Next.js 15 (App Router)
- React 19
- TypeScript (`.tsx` / `.ts`)
- Tailwind CSS 3 + `app/globals.css`
- Framer Motion (already in repo, optional for new pieces — most use CSS keyframes)

Visual reference: `angies-redesign.html` (the standalone mockup).

---

## File map — drag this folder into the repo

Every path in `angies-handoff/` mirrors the repo path it replaces or extends.

| This handoff file | → Repo destination | Action |
|---|---|---|
| `app/layout.tsx` | `app/layout.tsx` | **Merge** — swap font imports, keep everything else |
| `app/globals-additions.css` | `app/globals.css` | **Append** — add the contents to the bottom |
| `tailwind.config-additions.ts` | `tailwind.config.ts` | **Merge** — extend `theme.extend` with these keys |
| `components/marquee/BrandTicker.tsx` | `components/marquee/BrandTicker.tsx` | **New** |
| `components/hero/HeroBadge.tsx` | `components/hero/HeroBadge.tsx` | **New** |
| `components/hero/HeroLeaves.tsx` | `components/hero/HeroLeaves.tsx` | **New** |
| `components/locations/MapPinRadar.tsx` | `components/locations/MapPinRadar.tsx` | **New** |
| `components/locations/LocationPublicStatus.tsx` | `components/locations/LocationPublicStatus.tsx` | **Replace** |
| `components/ui/Reveal.tsx` | `components/ui/Reveal.tsx` | **New** |
| `components/ui/SectionHeading.tsx` | `components/ui/SectionHeading.tsx` | **Replace** |
| `components/prologue/Prologue.tsx` | `components/prologue/Prologue.tsx` | **Replace** |
| `components/cta/FinalConversion.tsx` | `components/cta/FinalConversion.tsx` | **Replace** |
| `lib/hooks/useReveal.ts` | `lib/hooks/useReveal.ts` | **New** |
| `PATCHES.md` | (no direct destination) | Patch instructions for files I can't safely rewrite blindly |

---

## Install order

1. **Fonts first.** Apply `app/layout.tsx` (merge). Add four font variables on `<body>`.
2. **Config next.** Append `app/globals-additions.css` to your `globals.css`. Merge `tailwind.config-additions.ts` into your config's `theme.extend`.
3. **Run a build** to confirm fonts load (`npm run build` or `dev`). You'll see Fraunces rendering immediately on existing headings.
4. **Drop new files in** — `BrandTicker`, `HeroBadge`, `HeroLeaves`, `MapPinRadar`, `Reveal`, `useReveal`. Nothing renders yet.
5. **Replace the simple components** — `SectionHeading`, `LocationPublicStatus`, `Prologue`, `FinalConversion`. Visual changes start showing.
6. **Apply patches** from `PATCHES.md` to `Hero.tsx`, `HomeView.tsx`, `InteractiveMenu.tsx`, `EditorialNav.tsx`, `SiteFooter.tsx`, `StorySection.tsx`, `LocationsSection.tsx`, `SocialPromoSection.tsx`, `glass-cta.ts`.
7. **Grep cleanup** — see the type role table below to catch remaining headings using old class strings.

---

## Type roles — the consistency rule

Every heading, kicker, body block, and price on the homepage maps to one of these classes (defined in `app/globals-additions.css`):

| Role | Class | Used for |
|---|---|---|
| Hero heading | `.t-hero` | Page-defining h1 only |
| Section heading | `.t-section` | Every section h2 |
| Pull-quote | `.t-quote` | Blockquote text |
| Kicker | `.t-kicker` (+ `t-kicker-gold` / `t-kicker-orange`) | Above headings |
| Body | `.t-body` / `.t-body-lg` | Paragraph text |
| Script accent | `.t-script` | Two places only (see below) |
| Micro / attribution | `.t-micro` | Quote attribution, micro-copy |
| Price (mono) | `.t-price-mono` | Menu prices |
| Hours (mono) | `.t-hours-mono` | Location hours |

**Script font (`Caveat`) discipline — STRICT.** Only two locations:
1. `Prologue.tsx` — "¡Bienvenidos!" above the welcome title.
2. `SiteFooter.tsx` — "Hecho con cariño" in the footer bottom row.

Scattering the script font breaks the entire system. Do not add it anywhere else without explicit approval.

---

## Grep targets (cleanup after rewrites land)

Search the repo and replace per this table. Most occurrences live in `components/**/*.tsx`.

| Old class string (or pattern) | New class |
|---|---|
| `font-display text-5xl ... lg:text-7xl text-cream` | `t-hero` |
| `font-display text-4xl sm:text-5xl text-cream` | `t-section` |
| `text-xs uppercase tracking-editorial text-cream/60` | `t-kicker` |
| `text-xs uppercase tracking-editorial text-gold/90` | `t-kicker t-kicker-gold` |
| `text-cream/75 sm:text-lg` | `t-body-lg` |
| `text-sm text-cream/75` | `t-body` |
| Price rendering (any `text-cream/85` near `$`) | `t-price-mono` |
| Hours rendering in `LocationsSection` | `t-hours-mono` |

Italic emphasis: any `<em>` inside `.t-hero`, `.t-section`, or `.t-quote` automatically gets the SOFT-axis flex + accent color from the role class. Don't add styling to the `<em>` itself.

---

## Motion inventory

Every motion piece, where it lives, and whether reduced-motion handles it:

| Piece | Component | Technique | Reduced motion? |
|---|---|---|---|
| Top marquee ticker | `BrandTicker.tsx` (new) | CSS keyframe `marquee` | ✅ global guard |
| Hero ken-burns | `Hero.tsx` (patch) | CSS keyframe `kenburns` | ✅ |
| Hero entrance stagger | `Hero.tsx` (patch) | Framer Motion `staggerChildren` | ✅ FM auto-disables |
| Spinning badge | `HeroBadge.tsx` (new) | SVG textPath + CSS `spin28` | ✅ |
| Drifting cilantro | `HeroLeaves.tsx` (new) | 6 SVG leaves + CSS `drift` | ✅ |
| OPEN ring pulse | `LocationPublicStatus.tsx` (replace) | CSS `ringPulse` | ✅ |
| Map pin radar | `MapPinRadar.tsx` (new) | CSS `radarPing` (×3 staggered) | ✅ |
| Scroll reveal stagger | `Reveal.tsx` (new) + `useReveal.ts` | IntersectionObserver + CSS transition | ✅ |
| Menu card tilt | `InteractiveMenu.tsx` (patch) | CSS hover transform | ✅ (cosmetic) |
| Button arrow slide | `glass-cta.ts` (patch) | CSS hover transform | ✅ (cosmetic) |

Reduced motion is handled **globally** in `globals-additions.css` — no per-component guards needed.

---

## Constraints preserved (do not break)

From the original spec, these stay UNCHANGED:

- Watermark + fixed brand backdrop structure (`FixedBrandBackdrop.tsx`)
- Hero opaque `bg-charcoal` base under the slideshow
- Glass-section opacity rule: `bg-charcoal/45 backdrop-blur-sm` on standard bands
- Footer glass: `bg-charcoal/70 backdrop-blur-md`
- Prologue card: `bg-charcoal/92`, NO `backdrop-blur` on the card itself
- Z-order: backdrop z-0, content z-10, nav z-50, drawer z-60+
- Existing color tokens (charcoal, cream, angie-orange, gold, salsa, accent-green, etc.)

No color tokens are changed in this handoff. If you also want a palette redesign, run BLOCKS A–G from the original spec separately.

---

## Verification checklist (Section 13 style)

```
[ ] Fonts swap: Playfair Display gone, Fraunces renders on h1/h2/blockquote
[ ] Caveat appears in exactly 2 places (Prologue, Footer bottom)
[ ] JetBrains Mono on menu prices + location hours
[ ] Top marquee scrolls above nav
[ ] Hero entrance stagger plays on first load
[ ] Spinning badge text orbits the hero logo (right side, desktop only)
[ ] Cilantro leaves drift up through hero
[ ] OPEN status dot has a radiating ring
[ ] Map pin has 3 staggered radar pings
[ ] Every section fades up on scroll
[ ] Menu cards lift + tilt on hover
[ ] Watermark still visible mid-page through glass sections
[ ] Hero is opaque at top (no watermark bleed through)
[ ] Prologue card has NO backdrop-blur (watermark visible around card)
[ ] prefers-reduced-motion disables all animations
[ ] Build passes: npm run build
```
