// components/hero/HeroBadge.tsx
// ──────────────────────────────────────────────────────────────────────────────
// The spinning circular-text "stamp" for the hero. Renders Angie's logo at
// the center with rotating text around the perimeter (textPath on a circle).
//
// Server component — pure SVG + CSS.
//
// USAGE: Drop into the hero's right-hand column on desktop. On mobile (<md),
// you can hide it via parent className or render conditionally.
// ──────────────────────────────────────────────────────────────────────────────

import Image from "next/image";

interface HeroBadgeProps {
  /** Text that orbits the logo. Repeat your phrase a few times so the path fills. */
  orbitText?: string;
  /** Logo src, defaults to the public path. */
  logoSrc?: string;
  /** Tailwind sizing on the outer wrapper. */
  className?: string;
}

export default function HeroBadge({
  orbitText = "Angies Fresh Food · Kansas City · Tex-Mex · Open the window · ",
  logoSrc = "/images/brand/site-logo.webp",
  className = "w-[220px] sm:w-[280px] lg:w-[320px]",
}: HeroBadgeProps) {
  // SVG textPath needs a unique id per render to avoid collisions.
  const pathId = "hero-badge-path";

  return (
    <div className={`relative aspect-square ${className}`} aria-hidden="true">
      {/* Ring of orbiting text — spins independently of the logo */}
      <svg
        viewBox="0 0 200 200"
        className="absolute inset-0 animate-spin28"
        style={{ willChange: "transform" }}
      >
        <defs>
          <path
            id={pathId}
            d="M 100,100 m -85,0 a 85,85 0 1,1 170,0 a 85,85 0 1,1 -170,0"
          />
        </defs>
        <text
          className="font-sans fill-gold"
          style={{
            fontSize: "9px",
            fontWeight: 600,
            letterSpacing: "0.4em",
            textTransform: "uppercase",
          }}
        >
          <textPath href={`#${pathId}`}>{orbitText}</textPath>
        </text>
      </svg>

      {/* Logo at center — gentle vertical bob */}
      <div
        className="absolute inset-[18%] animate-bob"
        style={{
          filter: "drop-shadow(0 0 24px rgba(247, 84, 45, 0.35))",
        }}
      >
        <Image
          src={logoSrc}
          alt=""
          fill
          sizes="320px"
          priority
          className="object-contain"
        />
      </div>
    </div>
  );
}
